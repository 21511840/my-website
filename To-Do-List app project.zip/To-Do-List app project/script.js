document.addEventListener('DOMContentLoaded', function () {
    // Get references to the DOM elements
    const addButton = document.getElementById('add-task-button');
    const inputBox = document.getElementById('input-box');
    const listContainer = document.getElementById('list-container');

    // Function to create a new list item
    function createListItem(taskText) {
        const listItem = document.createElement('li');
        listItem.textContent = taskText;
        
        // Create a span element for the action icon
        const actionSpan = document.createElement('span');
        actionSpan.innerHTML = '&#10005;'; // Using a cross symbol for remove action
        actionSpan.title = 'Remove Task';
        listItem.appendChild(actionSpan);

        // Toggle the completed state of the list item
        listItem.addEventListener('click', function () {
            listItem.classList.toggle('checked');
        });

        // Remove the task when the action icon is clicked
        actionSpan.addEventListener('click', function (e) {
            e.stopPropagation(); // Prevent triggering the click event on the list item
            listItem.remove();
        });

        return listItem;
    }

    // Add a new task to the list
    function addTask() {
        const taskText = inputBox.value.trim();
        if (taskText) {
            const listItem = createListItem(taskText);
            listContainer.appendChild(listItem);
            inputBox.value = ''; // Clear input box after adding the task
        }
    }

    // Add event listener to the Add Task button
    addButton.addEventListener('click', addTask);

    // Add event listener to the input box to add task on Enter key press
    inputBox.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault(); // Prevent form submission if input is in a form
            addTask();
        }
    });
});
