document.getElementById('contact-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form submission
    alert('Thank you for your message!');
    event.target.reset(); // Reset form
});

// Function to add product to cart
function addToCart(productName, price) {
    alert(`${productName} has been added to your cart for $${price}.`);
}

// Function to proceed to checkout
function checkout() {
    alert('Proceeding to checkout...');
    // Redirect to checkout page or handle checkout process
}

// Initialize cart total
let cartItems = []; // This would normally come from a database or local storage
let totalPrice = 0;

// Sample function for adding products to cart
function addToCart(productName, price) {
    cartItems.push(productName);
    totalPrice += price;
    document.getElementById('total-price').innerText = `$${totalPrice}`;
    alert(`${productName} added to the cart!`);
}
