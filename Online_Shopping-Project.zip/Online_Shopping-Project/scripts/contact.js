function sendMessage() {
    const messageInput = document.getElementById('chat-input');
    const messageText = messageInput.value.trim();
    if (messageText) {
        const chatMessages = document.getElementById('chat-messages');
        const newMessage = document.createElement('div');
        newMessage.textContent = `You: ${messageText}`;
        chatMessages.appendChild(newMessage);
        messageInput.value = '';
        chatMessages.scrollTop = chatMessages.scrollHeight; // Auto scroll to bottom
    }
}
